package partieB;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class LamportDistributedMutex {

    private static final int NB_PROCESSUS = 3;
    private static final double PROBA_PERTE = 0.0;
    private static final double PROBA_PANNE = 0.0;
    private static final boolean SIMULER_PANNE = true;
    private static final int DUREE_AVANT_PANNE_MS = 8000;
    private static final int DUREE_APRES_PANNE_MS = 10000;

    private static final AtomicLong tempsAttenteTotal = new AtomicLong(0);
    private static final AtomicInteger nbEntrees = new AtomicInteger(0);

    private static final Comparator<Message> ORDRE =
            Comparator.comparingInt((Message m) -> m.horloge).thenComparingInt(m -> m.idSource);

    static class CanalReseau {
        private final Random random = new Random();
        private final AtomicInteger compteurMessages = new AtomicInteger(0);
        private final AtomicInteger messagesPerdus = new AtomicInteger(0);
        private final ScheduledExecutorService scheduler =
                Executors.newSingleThreadScheduledExecutor();
        private final long[][] derniereLivraison;

        CanalReseau(int nbProcessus) {
            derniereLivraison = new long[nbProcessus + 1][nbProcessus + 1];
        }

        public synchronized void envoyerMessage(Processus src, Processus dest, Message msg) {
            compteurMessages.incrementAndGet();
            if (random.nextDouble() < PROBA_PERTE) {
                messagesPerdus.incrementAndGet();
                return;
            }
            long maintenant = System.currentTimeMillis();
            long delai = 300 + random.nextInt(500);
            long livraison = Math.max(maintenant + delai, derniereLivraison[src.id][dest.id] + 1);
            derniereLivraison[src.id][dest.id] = livraison;
            try {
                scheduler.schedule(() -> dest.recevoirMessage(msg),
                        livraison - maintenant, TimeUnit.MILLISECONDS);
            } catch (RejectedExecutionException ignored) {
            }
        }

        public int getNombreMessages() { return compteurMessages.get(); }
        public int getMessagesPerdus() { return messagesPerdus.get(); }
        public void arreter() { scheduler.shutdownNow(); }
    }

    enum TypeMessage { REQUEST, REPLY, RELEASE }

    static class Message {
        TypeMessage type;
        int horloge;
        int idSource;

        public Message(TypeMessage type, int horloge, int idSource) {
            this.type = type;
            this.horloge = horloge;
            this.idSource = idSource;
        }
    }

    static class Processus implements Runnable {
        final int id;
        final CanalReseau canal;
        List<Processus> autres = new ArrayList<>();
        int horlogeLamport = 0;
        volatile boolean enPanne = false;
        volatile boolean actif = true;

        final PriorityQueue<Message> fileRequetes = new PriorityQueue<>(ORDRE);
        final Set<Integer> reponsesRecues = new HashSet<>();

        public Processus(int id, CanalReseau canal) {
            this.id = id;
            this.canal = canal;
        }

        public void setEnPanne(boolean enPanne) { this.enPanne = enPanne; }
        public void arreter() { this.actif = false; }

        private void majHorloge(int autreHorloge) {
            horlogeLamport = Math.max(horlogeLamport, autreHorloge) + 1;
        }

        private Processus trouverProcessus(int idCherche) {
            for (Processus p : autres) {
                if (p.id == idCherche) return p;
            }
            return null;
        }

        private boolean estEnPanne(int idCherche) {
            if (idCherche == id) return enPanne;
            Processus p = trouverProcessus(idCherche);
            return p != null && p.enPanne;
        }

        public synchronized void recevoirMessage(Message msg) {
            if (enPanne) return;
            majHorloge(msg.horloge);
            switch (msg.type) {
                case REQUEST -> {
                    fileRequetes.add(msg);
                    afficherFile();
                    canal.envoyerMessage(this, trouverProcessus(msg.idSource),
                            new Message(TypeMessage.REPLY, horlogeLamport, id));
                }
                case REPLY -> reponsesRecues.add(msg.idSource);
                case RELEASE -> {
                    fileRequetes.removeIf(m -> m.idSource == msg.idSource);
                    afficherFile();
                }
            }
        }

        private synchronized boolean peutEntrer() {
            for (Processus p : autres) {
                if (!p.enPanne && !reponsesRecues.contains(p.id)) return false;
            }
            Message premier = null;
            for (Message m : fileRequetes) {
                if (estEnPanne(m.idSource)) continue;
                if (premier == null || ORDRE.compare(m, premier) < 0) premier = m;
            }
            return premier != null && premier.idSource == id;
        }

        public void demanderSectionCritique() throws InterruptedException {
            if (enPanne) return;
            long debut = System.currentTimeMillis();
            Message requete;
            synchronized (this) {
                horlogeLamport++;
                requete = new Message(TypeMessage.REQUEST, horlogeLamport, id);
                fileRequetes.add(requete);
                reponsesRecues.clear();
                System.out.println("P" + id + " demande la section critique (horloge="
                        + horlogeLamport + ")");
                afficherFile();
            }
            for (Processus p : autres) {
                canal.envoyerMessage(this, p, requete);
            }

            while (actif && !enPanne && !peutEntrer()) {
                Thread.sleep(50);
            }
            if (!actif || enPanne) return;

            tempsAttenteTotal.addAndGet(System.currentTimeMillis() - debut);
            nbEntrees.incrementAndGet();

            entrerSectionCritique();
            sortirSectionCritique();
        }

        private void entrerSectionCritique() throws InterruptedException {
            System.out.println(">>> P" + id + " ENTRE en section critique (horloge="
                    + horlogeLamport + ")");
            Thread.sleep(1000 + new Random().nextInt(1000));
        }

        private void sortirSectionCritique() {
            Message release;
            synchronized (this) {
                System.out.println("<<< P" + id + " QUITTE la section critique");
                fileRequetes.removeIf(m -> m.idSource == id);
                horlogeLamport++;
                release = new Message(TypeMessage.RELEASE, horlogeLamport, id);
                afficherFile();
            }
            for (Processus p : autres) {
                canal.envoyerMessage(this, p, release);
            }
        }

        private void afficherFile() {
            List<Message> liste = new ArrayList<>(fileRequetes);
            liste.sort(ORDRE);
            StringBuilder sb = new StringBuilder("    File de P" + id + " : [");
            for (Message m : liste) {
                sb.append("P").append(m.idSource).append("@").append(m.horloge).append(" ");
            }
            sb.append("]");
            System.out.println(sb);
        }

        @Override
        public void run() {
            try {
                while (actif && !enPanne) {
                    demanderSectionCritique();
                    Thread.sleep(1000 + new Random().nextInt(2000));
                    if (new Random().nextDouble() < PROBA_PANNE) {
                        System.out.println("\n*** P" + id + " tombe en panne (aléatoire) ! ***\n");
                        enPanne = true;
                    }
                }
            } catch (InterruptedException ignored) {
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        CanalReseau canal = new CanalReseau(NB_PROCESSUS);

        List<Processus> tous = new ArrayList<>();
        for (int i = 1; i <= NB_PROCESSUS; i++) {
            tous.add(new Processus(i, canal));
        }
        for (Processus p : tous) {
            p.autres = new ArrayList<>(tous);
            p.autres.remove(p);
        }

        List<Thread> fils = new ArrayList<>();
        for (Processus p : tous) {
            Thread t = new Thread(p, "P" + p.id);
            fils.add(t);
            t.start();
        }

        Thread.sleep(DUREE_AVANT_PANNE_MS);
        if (SIMULER_PANNE && NB_PROCESSUS >= 2) {
            System.out.println("\n*** P2 tombe en panne ! ***\n");
            tous.get(1).setEnPanne(true);
        }
        Thread.sleep(DUREE_APRES_PANNE_MS);

        for (Processus p : tous) p.arreter();
        for (Thread t : fils) t.join();
        canal.arreter();

        System.out.println("\n===== STATISTIQUES =====");
        System.out.println("Nombre de processus : " + NB_PROCESSUS);
        System.out.println("Nombre total de messages échangés : " + canal.getNombreMessages());
        System.out.println("Messages perdus : " + canal.getMessagesPerdus());
        System.out.println("Entrées en section critique : " + nbEntrees.get());
        if (nbEntrees.get() > 0) {
            System.out.println("Temps moyen d'attente pour entrer en SC : "
                    + (tempsAttenteTotal.get() / nbEntrees.get()) + " ms");
        }
        System.out.println("=========================");
    }
}