package partieA;

import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class Processus extends Thread {
    private static final AtomicInteger termines = new AtomicInteger(0);

    private final int id;
    private int clock = 0;
    private List<Processus> autres;
    private final Queue<Message> fileMessages = new ConcurrentLinkedQueue<>();
    private final Set<Integer> reponsesRecues = new HashSet<>();
    private final List<Message> fileDemandes = new ArrayList<>();

    public Processus(int id) {
        this.id = id;
    }

    public void setAutres(List<Processus> autres) {
        this.autres = autres;
    }

    private synchronized int tick() {
        clock++;
        return clock;
    }

    private synchronized void majHorloge(int autreHorloge) {
        clock = Math.max(clock, autreHorloge) + 1;
    }

    private synchronized int getClock() {
        return clock;
    }

    private void envoyer(Message m, Processus dest) {
        dest.recoitMessage(m);
    }

    public void recoitMessage(Message m) {
        majHorloge(m.timestamp);
        fileMessages.add(m);
    }

    private void broadcast(Message m) {
        for (Processus p : autres) {
            if (p.id != this.id)
                envoyer(m, p);
        }
    }

    // Ma requête est-elle la plus ancienne (horloge, puis id) ?
    private boolean suisPremier() {
        Message min = null;
        for (Message m : fileDemandes) {
            if (min == null || m.timestamp < min.timestamp
                    || (m.timestamp == min.timestamp && m.senderId < min.senderId)) {
                min = m;
            }
        }
        return min != null && min.senderId == id;
    }

    private void demandeSC() throws InterruptedException {
        System.out.println("Processus " + id + " demande SC à t=" + getClock());
        Message demande = new Message(Message.Type.REQUEST, id, tick());
        fileDemandes.add(demande);
        reponsesRecues.clear();
        reponsesRecues.add(id); // s'auto-approuve
        broadcast(demande);

        // Condition 1 : REPLY de tous. Condition 2 : ma requête est la première.
        while (reponsesRecues.size() < autres.size() || !suisPremier()) {
            traiterMessages();
            Thread.sleep(50);
        }
        entrerSC();
    }

    private void entrerSC() throws InterruptedException {
        System.out.println("==> Processus " + id + " entre en SC (t=" + getClock() + ")");
        Thread.sleep(1000);
        sortirSC();
    }

    private void sortirSC() {
        System.out.println("<== Processus " + id + " quitte SC (t=" + getClock() + ")");
        fileDemandes.removeIf(m -> m.senderId == id);
        broadcast(new Message(Message.Type.RELEASE, id, tick()));
    }

    private void traiterMessages() {
        while (!fileMessages.isEmpty()) {
            Message m = fileMessages.poll();
            switch (m.type) {
                case REQUEST:
                    fileDemandes.add(m);
                    envoyer(new Message(Message.Type.REPLY, id, tick()), getProcessus(m.senderId));
                    break;
                case REPLY:
                    reponsesRecues.add(m.senderId);
                    break;
                case RELEASE:
                    fileDemandes.removeIf(x -> x.senderId == m.senderId);
                    break;
            }
        }
    }

    private Processus getProcessus(int id) {
        for (Processus p : autres) {
            if (p.id == id) return p;
        }
        return null;
    }

    // Attente pendant laquelle on continue de répondre aux autres
    private void attendre(long ms) throws InterruptedException {
        long fin = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < fin) {
            traiterMessages();
            Thread.sleep(50);
        }
    }

    @Override
    public void run() {
        try {
            for (int i = 0; i < 3; i++) {
                attendre(500 + new Random().nextInt(1000));
                demandeSC();
            }
            termines.incrementAndGet();
            // Continue de répondre tant que les autres n'ont pas fini
            while (termines.get() < autres.size()) {
                traiterMessages();
                Thread.sleep(50);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}