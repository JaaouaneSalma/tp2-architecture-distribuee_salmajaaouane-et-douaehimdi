package com.example.tp3lamport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp3LamportApplication {

    public static void main(String[] args) {
        SpringApplication.run(Tp3LamportApplication.class, args);
    }

}
